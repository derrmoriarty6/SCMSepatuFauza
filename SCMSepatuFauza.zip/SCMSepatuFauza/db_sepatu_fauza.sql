-- phpMyAdmin SQL Dump
-- Database: `db_sepatu_fauza`
--

CREATE DATABASE IF NOT EXISTS `db_sepatu_fauza`;
USE `db_sepatu_fauza`;

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbladmin`
--
CREATE TABLE `tbladmin` (
  `username` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbladmin`
--
INSERT INTO `tbladmin` (`username`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tblsepatu`
--
CREATE TABLE `tblsepatu` (
  `kd_sepatu` varchar(10) NOT NULL,
  `nama_sepatu` varchar(50) NOT NULL,
  `merk` varchar(30) NOT NULL DEFAULT 'Bunut',
  `ukuran` varchar(10) NOT NULL,
  `warna` varchar(20) NOT NULL,
  `jenis` varchar(20) NOT NULL,
  `stok` int(5) NOT NULL,
  `harga` double NOT NULL,
  `kd_supplier` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tblsepatu`
--
INSERT INTO `tblsepatu` (`kd_sepatu`, `nama_sepatu`, `merk`, `ukuran`, `warna`, `jenis`, `stok`, `harga`, `kd_supplier`) VALUES
('S001', 'Bunut Classic Leather', 'Bunut', '42', 'Coklat', 'Formal', 15, 350000, 'SP01'),
('S002', 'Bunut Daily Sneakers', 'Bunut', '40', 'Putih', 'Sneakers', 20, 250000, 'SP02'),
('S003', 'Bunut Boots Adventure', 'Bunut', '43', 'Hitam', 'Boots', 10, 550000, 'SP01');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tblsupplier`
--
CREATE TABLE `tblsupplier` (
  `kd_supplier` varchar(10) NOT NULL,
  `nama_supplier` varchar(50) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `telp` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tblsupplier`
--
INSERT INTO `tblsupplier` (`kd_supplier`, `nama_supplier`, `alamat`, `telp`) VALUES
('SP01', 'CV. Bunut Leather M', 'Jl. Kisaran No. 12', '081234567891'),
('SP02', 'PT. Sepatu Sumatera', 'Jl. Lintas Timur No. 5', '081234567892');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tblkategori`
--
CREATE TABLE `tblkategori` (
  `kd_kategori` varchar(10) NOT NULL,
  `nama_kategori` varchar(30) NOT NULL,
  `keterangan` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tblkategori`
--
INSERT INTO `tblkategori` (`kd_kategori`, `nama_kategori`, `keterangan`) VALUES
('K01', 'Pria', 'Sepatu khusus untuk pria dewasa'),
('K02', 'Wanita', 'Sepatu khusus untuk wanita dewasa'),
('K03', 'Anak-Anak', 'Sepatu untuk anak-anak');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbltransaksi`
--
CREATE TABLE `tbltransaksi` (
  `id_transaksi` int(11) NOT NULL,
  `tgl_transaksi` date NOT NULL,
  `kd_sepatu` varchar(10) NOT NULL,
  `kd_kategori` varchar(10) NOT NULL,
  `kd_supplier` varchar(10) NOT NULL,
  `jumlah` int(5) NOT NULL,
  `harga_satuan` double NOT NULL,
  `diskon` double NOT NULL,
  `total_harga` double NOT NULL,
  `metode_bayar` varchar(20) NOT NULL,
  `keterangan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbltransaksi`
--
INSERT INTO `tbltransaksi` (`id_transaksi`, `tgl_transaksi`, `kd_sepatu`, `kd_kategori`, `kd_supplier`, `jumlah`, `harga_satuan`, `diskon`, `total_harga`, `metode_bayar`, `keterangan`) VALUES
(1, '2026-05-26', 'S001', 'K01', 'SP01', 2, 350000, 10, 630000, 'Cash', 'Lunas');

-- --------------------------------------------------------

--
-- Stand-in struktur untuk tampilan `querytransaksi`
--
CREATE TABLE `querytransaksi` (
`id_transaksi` int(11)
,`tgl_transaksi` date
,`kd_sepatu` varchar(10)
,`nama_sepatu` varchar(50)
,`merk` varchar(30)
,`ukuran` varchar(10)
,`warna` varchar(20)
,`jenis` varchar(20)
,`kd_kategori` varchar(10)
,`nama_kategori` varchar(30)
,`kd_supplier` varchar(10)
,`nama_supplier` varchar(50)
,`jumlah` int(5)
,`harga_satuan` double
,`diskon` double
,`total_harga` double
,`metode_bayar` varchar(20)
,`keterangan` varchar(50)
);

-- --------------------------------------------------------

--
-- Struktur untuk view `querytransaksi`
--
DROP TABLE IF EXISTS `querytransaksi`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `querytransaksi`  AS  
select 
  `t`.`id_transaksi` AS `id_transaksi`,
  `t`.`tgl_transaksi` AS `tgl_transaksi`,
  `t`.`kd_sepatu` AS `kd_sepatu`,
  `s`.`nama_sepatu` AS `nama_sepatu`,
  `s`.`merk` AS `merk`,
  `s`.`ukuran` AS `ukuran`,
  `s`.`warna` AS `warna`,
  `s`.`jenis` AS `jenis`,
  `t`.`kd_kategori` AS `kd_kategori`,
  `k`.`nama_kategori` AS `nama_kategori`,
  `t`.`kd_supplier` AS `kd_supplier`,
  `sup`.`nama_supplier` AS `nama_supplier`,
  `t`.`jumlah` AS `jumlah`,
  `t`.`harga_satuan` AS `harga_satuan`,
  `t`.`diskon` AS `diskon`,
  `t`.`total_harga` AS `total_harga`,
  `t`.`metode_bayar` AS `metode_bayar`,
  `t`.`keterangan` AS `keterangan` 
from (((`tbltransaksi` `t` 
join `tblsepatu` `s`) 
join `tblkategori` `k`) 
join `tblsupplier` `sup`) 
where ((`t`.`kd_sepatu` = `s`.`kd_sepatu`) and (`t`.`kd_kategori` = `k`.`kd_kategori`) and (`t`.`kd_supplier` = `sup`.`kd_supplier`));

-- --------------------------------------------------------

--
-- Indexes for dumped tables
--

ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`username`);

ALTER TABLE `tblsepatu`
  ADD PRIMARY KEY (`kd_sepatu`);

ALTER TABLE `tblsupplier`
  ADD PRIMARY KEY (`kd_supplier`);

ALTER TABLE `tblkategori`
  ADD PRIMARY KEY (`kd_kategori`);

ALTER TABLE `tbltransaksi`
  ADD PRIMARY KEY (`id_transaksi`);

--
-- AUTO_INCREMENT for dumped tables
--

ALTER TABLE `tbltransaksi`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;
