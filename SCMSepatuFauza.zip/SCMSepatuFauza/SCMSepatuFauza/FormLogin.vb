Imports MySql.Data.MySqlClient

Public Class FormLogin
    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End
    End Sub

    Private Sub btnLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogin.Click
        Try
            If txtUsername.Text = "" Or txtPassword.Text = "" Then
                MsgBox("Username dan Password harus diisi!", MsgBoxStyle.Exclamation, "Peringatan")
                txtUsername.Focus()
                Exit Sub
            End If

            Call KoneksiKeDatabase()
            cmd = New MySqlCommand("SELECT * FROM tbladmin WHERE username='" & txtUsername.Text & "' AND password='" & txtPassword.Text & "'", Conn)
            RD = cmd.ExecuteReader
            RD.Read()

            If RD.HasRows = True Then
                MsgBox("Login Berhasil!", MsgBoxStyle.Information, "Sukses")
                Me.Hide()
                F_MenuUtama.Show()
            Else
                MsgBox("Username atau Password salah!", MsgBoxStyle.Critical, "Gagal Login")
                txtUsername.Text = ""
                txtPassword.Text = ""
                txtUsername.Focus()
            End If
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    Private Sub FormLogin_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        txtUsername.Focus()
    End Sub
End Class
