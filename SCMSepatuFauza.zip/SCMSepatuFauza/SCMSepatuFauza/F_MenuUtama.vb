Public Class F_MenuUtama

    Private Sub SepatuToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SepatuToolStripMenuItem.Click
        FormSepatu.ShowDialog()
    End Sub

    Private Sub SupplierToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SupplierToolStripMenuItem.Click
        FormSupplier.ShowDialog()
    End Sub

    Private Sub KategoriToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KategoriToolStripMenuItem.Click
        FormKategori.ShowDialog()
    End Sub

    Private Sub TransaksiKasirToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TransaksiKasirToolStripMenuItem.Click
        FormTransaksi.ShowDialog()
    End Sub

    Private Sub SepatuToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SepatuToolStripMenuItem1.Click
        FormCariSepatu.ShowDialog()
    End Sub

    Private Sub SupplierToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SupplierToolStripMenuItem1.Click
        FormCariSupplier.ShowDialog()
    End Sub

    Private Sub KategoriToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KategoriToolStripMenuItem1.Click
        FormCariKategori.ShowDialog()
    End Sub

    Private Sub KeluarToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KeluarToolStripMenuItem.Click
        End
    End Sub

    Private Sub F_MenuUtama_FormClosed(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles MyBase.FormClosed
        End
    End Sub
End Class
