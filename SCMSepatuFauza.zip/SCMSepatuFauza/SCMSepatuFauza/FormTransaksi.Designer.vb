<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormTransaksi
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        
        Me.txtIdTransaksi = New System.Windows.Forms.TextBox()
        Me.dtpTanggal = New System.Windows.Forms.DateTimePicker()
        Me.txtKodeSepatu = New System.Windows.Forms.TextBox()
        Me.txtNamaSepatu = New System.Windows.Forms.TextBox()
        Me.txtMerk = New System.Windows.Forms.TextBox()
        
        Me.txtKodeKategori = New System.Windows.Forms.TextBox()
        Me.txtNamaKategori = New System.Windows.Forms.TextBox()
        
        Me.txtKodeSupplier = New System.Windows.Forms.TextBox()
        Me.txtNamaSupplier = New System.Windows.Forms.TextBox()
        
        Me.txtJumlah = New System.Windows.Forms.TextBox()
        Me.txtHargaSatuan = New System.Windows.Forms.TextBox()
        Me.txtDiskon = New System.Windows.Forms.TextBox()
        Me.txtTotalHarga = New System.Windows.Forms.TextBox()
        Me.cbMetodeBayar = New System.Windows.Forms.ComboBox()
        Me.txtKeterangan = New System.Windows.Forms.TextBox()
        
        Me.btnCariSepatu = New System.Windows.Forms.Button()
        Me.btnCariKategori = New System.Windows.Forms.Button()
        Me.btnCariSupplier = New System.Windows.Forms.Button()
        
        Me.btnRefresh = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.Panel1 = New System.Windows.Forms.Panel()
        
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        
        ' Label1
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.SaddleBrown
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label1.Location = New System.Drawing.Point(350, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(280, 26)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "FORM TRANSAKSI KASIR"
        
        ' Label2
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.Label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label2.Location = New System.Drawing.Point(40, 80)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(90, 18)
        Me.Label2.Text = "ID Transaksi"
        
        ' Label3
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.Label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label3.Location = New System.Drawing.Point(40, 110)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(60, 18)
        Me.Label3.Text = "Tanggal"
        
        ' Label4
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.Label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label4.Location = New System.Drawing.Point(40, 140)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(55, 18)
        Me.Label4.Text = "Sepatu"
        
        ' Label5
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.Label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label5.Location = New System.Drawing.Point(40, 170)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(64, 18)
        Me.Label5.Text = "Kategori"
        
        ' Label6
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.Label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label6.Location = New System.Drawing.Point(40, 200)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(60, 18)
        Me.Label6.Text = "Supplier"
        
        ' Label7
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.Label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label7.Location = New System.Drawing.Point(540, 80)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(55, 18)
        Me.Label7.Text = "Jumlah"
        
        ' Label8
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.Label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label8.Location = New System.Drawing.Point(540, 110)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(48, 18)
        Me.Label8.Text = "Harga"
        
        ' Label9
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.Label9.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label9.Location = New System.Drawing.Point(540, 140)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(78, 18)
        Me.Label9.Text = "Diskon (%)"
        
        ' Label10
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.Label10.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label10.Location = New System.Drawing.Point(540, 170)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(41, 18)
        Me.Label10.Text = "Total"

        ' Label12
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.Label12.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label12.Location = New System.Drawing.Point(540, 200)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(100, 18)
        Me.Label12.Text = "Metode Bayar"
        
        ' Label13
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.Label13.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label13.Location = New System.Drawing.Point(540, 230)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(83, 18)
        Me.Label13.Text = "Keterangan"

        ' txtIdTransaksi
        Me.txtIdTransaksi.Location = New System.Drawing.Point(150, 80)
        Me.txtIdTransaksi.Name = "txtIdTransaksi"
        Me.txtIdTransaksi.ReadOnly = True
        Me.txtIdTransaksi.Size = New System.Drawing.Size(80, 20)
        
        ' dtpTanggal
        Me.dtpTanggal.Location = New System.Drawing.Point(150, 110)
        Me.dtpTanggal.Name = "dtpTanggal"
        Me.dtpTanggal.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtpTanggal.Size = New System.Drawing.Size(100, 20)
        
        ' txtKodeSepatu
        Me.txtKodeSepatu.Location = New System.Drawing.Point(150, 140)
        Me.txtKodeSepatu.Name = "txtKodeSepatu"
        Me.txtKodeSepatu.Size = New System.Drawing.Size(60, 20)
        Me.txtKodeSepatu.ReadOnly = True
        
        ' btnCariSepatu
        Me.btnCariSepatu.Location = New System.Drawing.Point(215, 139)
        Me.btnCariSepatu.Name = "btnCariSepatu"
        Me.btnCariSepatu.Size = New System.Drawing.Size(30, 22)
        Me.btnCariSepatu.Text = "..."
        
        ' txtNamaSepatu
        Me.txtNamaSepatu.Location = New System.Drawing.Point(250, 140)
        Me.txtNamaSepatu.Name = "txtNamaSepatu"
        Me.txtNamaSepatu.Size = New System.Drawing.Size(150, 20)
        Me.txtNamaSepatu.ReadOnly = True
        
        ' txtMerk
        Me.txtMerk.Location = New System.Drawing.Point(405, 140)
        Me.txtMerk.Name = "txtMerk"
        Me.txtMerk.Size = New System.Drawing.Size(80, 20)
        Me.txtMerk.ReadOnly = True
        
        ' txtKodeKategori
        Me.txtKodeKategori.Location = New System.Drawing.Point(150, 170)
        Me.txtKodeKategori.Name = "txtKodeKategori"
        Me.txtKodeKategori.Size = New System.Drawing.Size(60, 20)
        Me.txtKodeKategori.ReadOnly = True
        
        ' btnCariKategori
        Me.btnCariKategori.Location = New System.Drawing.Point(215, 169)
        Me.btnCariKategori.Name = "btnCariKategori"
        Me.btnCariKategori.Size = New System.Drawing.Size(30, 22)
        Me.btnCariKategori.Text = "..."
        
        ' txtNamaKategori
        Me.txtNamaKategori.Location = New System.Drawing.Point(250, 170)
        Me.txtNamaKategori.Name = "txtNamaKategori"
        Me.txtNamaKategori.Size = New System.Drawing.Size(150, 20)
        Me.txtNamaKategori.ReadOnly = True

        ' txtKodeSupplier
        Me.txtKodeSupplier.Location = New System.Drawing.Point(150, 200)
        Me.txtKodeSupplier.Name = "txtKodeSupplier"
        Me.txtKodeSupplier.Size = New System.Drawing.Size(60, 20)
        Me.txtKodeSupplier.ReadOnly = True
        
        ' btnCariSupplier
        Me.btnCariSupplier.Location = New System.Drawing.Point(215, 199)
        Me.btnCariSupplier.Name = "btnCariSupplier"
        Me.btnCariSupplier.Size = New System.Drawing.Size(30, 22)
        Me.btnCariSupplier.Text = "..."
        
        ' txtNamaSupplier
        Me.txtNamaSupplier.Location = New System.Drawing.Point(250, 200)
        Me.txtNamaSupplier.Name = "txtNamaSupplier"
        Me.txtNamaSupplier.Size = New System.Drawing.Size(150, 20)
        Me.txtNamaSupplier.ReadOnly = True

        ' txtJumlah
        Me.txtJumlah.Location = New System.Drawing.Point(650, 80)
        Me.txtJumlah.Name = "txtJumlah"
        Me.txtJumlah.Size = New System.Drawing.Size(80, 20)
        
        ' txtHargaSatuan
        Me.txtHargaSatuan.Location = New System.Drawing.Point(650, 110)
        Me.txtHargaSatuan.Name = "txtHargaSatuan"
        Me.txtHargaSatuan.Size = New System.Drawing.Size(120, 20)
        Me.txtHargaSatuan.ReadOnly = True
        
        ' txtDiskon
        Me.txtDiskon.Location = New System.Drawing.Point(650, 140)
        Me.txtDiskon.Name = "txtDiskon"
        Me.txtDiskon.Size = New System.Drawing.Size(80, 20)
        Me.txtDiskon.Text = "0"
        
        ' txtTotalHarga
        Me.txtTotalHarga.Location = New System.Drawing.Point(650, 170)
        Me.txtTotalHarga.Name = "txtTotalHarga"
        Me.txtTotalHarga.Size = New System.Drawing.Size(120, 20)
        Me.txtTotalHarga.ReadOnly = True
        
        ' cbMetodeBayar
        Me.cbMetodeBayar.Items.AddRange(New Object() {"Cash", "Transfer", "E-Wallet"})
        Me.cbMetodeBayar.Location = New System.Drawing.Point(650, 200)
        Me.cbMetodeBayar.Name = "cbMetodeBayar"
        Me.cbMetodeBayar.Size = New System.Drawing.Size(120, 21)
        Me.cbMetodeBayar.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        
        ' txtKeterangan
        Me.txtKeterangan.Location = New System.Drawing.Point(650, 230)
        Me.txtKeterangan.Name = "txtKeterangan"
        Me.txtKeterangan.Size = New System.Drawing.Size(200, 20)

        ' btnRefresh
        Me.btnRefresh.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnRefresh.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold)
        Me.btnRefresh.Location = New System.Drawing.Point(40, 250)
        Me.btnRefresh.Name = "btnRefresh"
        Me.btnRefresh.Size = New System.Drawing.Size(80, 30)
        Me.btnRefresh.Text = "REFRESH"
        Me.btnRefresh.UseVisualStyleBackColor = False
        
        ' btnSave
        Me.btnSave.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold)
        Me.btnSave.Location = New System.Drawing.Point(130, 250)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(80, 30)
        Me.btnSave.Text = "SAVE"
        Me.btnSave.UseVisualStyleBackColor = False
        
        ' btnDelete
        Me.btnDelete.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold)
        Me.btnDelete.Location = New System.Drawing.Point(220, 250)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(80, 30)
        Me.btnDelete.Text = "DELETE"
        Me.btnDelete.UseVisualStyleBackColor = False
        
        ' btnExit
        Me.btnExit.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold)
        Me.btnExit.Location = New System.Drawing.Point(310, 250)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(80, 30)
        Me.btnExit.Text = "EXIT"
        Me.btnExit.UseVisualStyleBackColor = False

        ' ListView1
        Me.ListView1.FullRowSelect = True
        Me.ListView1.GridLines = True
        Me.ListView1.Location = New System.Drawing.Point(40, 290)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(900, 230)
        Me.ListView1.TabIndex = 32
        Me.ListView1.View = System.Windows.Forms.View.Details

        ' Panel1
        Me.Panel1.BackColor = System.Drawing.Color.DarkSlateGray
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.Label12)
        Me.Panel1.Controls.Add(Me.Label13)
        Me.Panel1.Controls.Add(Me.txtIdTransaksi)
        Me.Panel1.Controls.Add(Me.dtpTanggal)
        Me.Panel1.Controls.Add(Me.txtKodeSepatu)
        Me.Panel1.Controls.Add(Me.btnCariSepatu)
        Me.Panel1.Controls.Add(Me.txtNamaSepatu)
        Me.Panel1.Controls.Add(Me.txtMerk)
        Me.Panel1.Controls.Add(Me.txtKodeKategori)
        Me.Panel1.Controls.Add(Me.btnCariKategori)
        Me.Panel1.Controls.Add(Me.txtNamaKategori)
        Me.Panel1.Controls.Add(Me.txtKodeSupplier)
        Me.Panel1.Controls.Add(Me.btnCariSupplier)
        Me.Panel1.Controls.Add(Me.txtNamaSupplier)
        Me.Panel1.Controls.Add(Me.txtJumlah)
        Me.Panel1.Controls.Add(Me.txtHargaSatuan)
        Me.Panel1.Controls.Add(Me.txtDiskon)
        Me.Panel1.Controls.Add(Me.txtTotalHarga)
        Me.Panel1.Controls.Add(Me.cbMetodeBayar)
        Me.Panel1.Controls.Add(Me.txtKeterangan)
        Me.Panel1.Controls.Add(Me.btnRefresh)
        Me.Panel1.Controls.Add(Me.btnSave)
        Me.Panel1.Controls.Add(Me.btnDelete)
        Me.Panel1.Controls.Add(Me.btnExit)
        Me.Panel1.Controls.Add(Me.ListView1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(980, 550)
        Me.Panel1.TabIndex = 0

        ' FormTransaksi
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(980, 550)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "FormTransaksi"
        Me.Text = "Transaksi - SCM Sepatu Fauza"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txtIdTransaksi As System.Windows.Forms.TextBox
    Friend WithEvents dtpTanggal As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtKodeSepatu As System.Windows.Forms.TextBox
    Friend WithEvents txtNamaSepatu As System.Windows.Forms.TextBox
    Friend WithEvents txtMerk As System.Windows.Forms.TextBox
    Friend WithEvents txtKodeKategori As System.Windows.Forms.TextBox
    Friend WithEvents txtNamaKategori As System.Windows.Forms.TextBox
    Friend WithEvents txtKodeSupplier As System.Windows.Forms.TextBox
    Friend WithEvents txtNamaSupplier As System.Windows.Forms.TextBox
    Friend WithEvents txtJumlah As System.Windows.Forms.TextBox
    Friend WithEvents txtHargaSatuan As System.Windows.Forms.TextBox
    Friend WithEvents txtDiskon As System.Windows.Forms.TextBox
    Friend WithEvents txtTotalHarga As System.Windows.Forms.TextBox
    Friend WithEvents cbMetodeBayar As System.Windows.Forms.ComboBox
    Friend WithEvents txtKeterangan As System.Windows.Forms.TextBox
    Friend WithEvents btnCariSepatu As System.Windows.Forms.Button
    Friend WithEvents btnCariKategori As System.Windows.Forms.Button
    Friend WithEvents btnCariSupplier As System.Windows.Forms.Button
    Friend WithEvents btnRefresh As System.Windows.Forms.Button
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents ListView1 As System.Windows.Forms.ListView
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
End Class
