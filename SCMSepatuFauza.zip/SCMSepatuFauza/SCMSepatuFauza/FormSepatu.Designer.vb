<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormSepatu
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        
        Me.txtKodeSepatu = New System.Windows.Forms.TextBox()
        Me.txtNamaSepatu = New System.Windows.Forms.TextBox()
        Me.txtMerk = New System.Windows.Forms.TextBox()
        Me.txtUkuran = New System.Windows.Forms.TextBox()
        Me.txtWarna = New System.Windows.Forms.TextBox()
        
        Me.cbSneakers = New System.Windows.Forms.CheckBox()
        Me.cbFormal = New System.Windows.Forms.CheckBox()
        Me.cbCasual = New System.Windows.Forms.CheckBox()
        Me.cbSport = New System.Windows.Forms.CheckBox()
        Me.cbBoots = New System.Windows.Forms.CheckBox()
        
        Me.txtStok = New System.Windows.Forms.TextBox()
        Me.txtHarga = New System.Windows.Forms.TextBox()
        Me.txtKodeSupplier = New System.Windows.Forms.TextBox()
        
        Me.btnRefresh = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnEdit = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtCariData = New System.Windows.Forms.TextBox()
        Me.btnCariData = New System.Windows.Forms.Button()
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.Panel1 = New System.Windows.Forms.Panel()
        
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        
        ' Label1
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.SaddleBrown
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label1.Location = New System.Drawing.Point(300, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(280, 26)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "FORM INPUT DATA SEPATU"
        
        ' Label2
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.Label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label2.Location = New System.Drawing.Point(40, 80)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(95, 18)
        Me.Label2.Text = "Kode Sepatu"
        
        ' Label3
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.Label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label3.Location = New System.Drawing.Point(40, 110)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(100, 18)
        Me.Label3.Text = "Nama Sepatu"
        
        ' Label4
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.Label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label4.Location = New System.Drawing.Point(40, 140)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(42, 18)
        Me.Label4.Text = "Merk"
        
        ' Label5
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.Label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label5.Location = New System.Drawing.Point(40, 170)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(56, 18)
        Me.Label5.Text = "Ukuran"
        
        ' Label6
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.Label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label6.Location = New System.Drawing.Point(40, 200)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(53, 18)
        Me.Label6.Text = "Warna"
        
        ' Label7
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.Label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label7.Location = New System.Drawing.Point(400, 80)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(43, 18)
        Me.Label7.Text = "Jenis"
        
        ' Label8
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.Label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label8.Location = New System.Drawing.Point(400, 110)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(39, 18)
        Me.Label8.Text = "Stok"
        
        ' Label9
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.Label9.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label9.Location = New System.Drawing.Point(400, 140)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(48, 18)
        Me.Label9.Text = "Harga"
        
        ' Label10
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.Label10.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label10.Location = New System.Drawing.Point(400, 170)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(102, 18)
        Me.Label10.Text = "Kode Supplier"

        ' txtKodeSepatu
        Me.txtKodeSepatu.Location = New System.Drawing.Point(150, 80)
        Me.txtKodeSepatu.Name = "txtKodeSepatu"
        Me.txtKodeSepatu.Size = New System.Drawing.Size(120, 20)
        
        ' txtNamaSepatu
        Me.txtNamaSepatu.Location = New System.Drawing.Point(150, 110)
        Me.txtNamaSepatu.Name = "txtNamaSepatu"
        Me.txtNamaSepatu.Size = New System.Drawing.Size(200, 20)
        
        ' txtMerk
        Me.txtMerk.Location = New System.Drawing.Point(150, 140)
        Me.txtMerk.Name = "txtMerk"
        Me.txtMerk.Size = New System.Drawing.Size(150, 20)
        Me.txtMerk.Text = "Bunut"
        
        ' txtUkuran
        Me.txtUkuran.Location = New System.Drawing.Point(150, 170)
        Me.txtUkuran.Name = "txtUkuran"
        Me.txtUkuran.Size = New System.Drawing.Size(60, 20)
        
        ' txtWarna
        Me.txtWarna.Location = New System.Drawing.Point(150, 200)
        Me.txtWarna.Name = "txtWarna"
        Me.txtWarna.Size = New System.Drawing.Size(120, 20)
        
        ' cbSneakers
        Me.cbSneakers.AutoSize = True
        Me.cbSneakers.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cbSneakers.Location = New System.Drawing.Point(520, 82)
        Me.cbSneakers.Name = "cbSneakers"
        Me.cbSneakers.Size = New System.Drawing.Size(71, 17)
        Me.cbSneakers.Text = "Sneakers"
        
        ' cbFormal
        Me.cbFormal.AutoSize = True
        Me.cbFormal.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cbFormal.Location = New System.Drawing.Point(600, 82)
        Me.cbFormal.Name = "cbFormal"
        Me.cbFormal.Size = New System.Drawing.Size(57, 17)
        Me.cbFormal.Text = "Formal"
        
        ' cbCasual
        Me.cbCasual.AutoSize = True
        Me.cbCasual.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cbCasual.Location = New System.Drawing.Point(670, 82)
        Me.cbCasual.Name = "cbCasual"
        Me.cbCasual.Size = New System.Drawing.Size(58, 17)
        Me.cbCasual.Text = "Casual"
        
        ' cbSport
        Me.cbSport.AutoSize = True
        Me.cbSport.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cbSport.Location = New System.Drawing.Point(740, 82)
        Me.cbSport.Name = "cbSport"
        Me.cbSport.Size = New System.Drawing.Size(51, 17)
        Me.cbSport.Text = "Sport"
        
        ' cbBoots
        Me.cbBoots.AutoSize = True
        Me.cbBoots.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cbBoots.Location = New System.Drawing.Point(800, 82)
        Me.cbBoots.Name = "cbBoots"
        Me.cbBoots.Size = New System.Drawing.Size(53, 17)
        Me.cbBoots.Text = "Boots"

        ' txtStok
        Me.txtStok.Location = New System.Drawing.Point(520, 110)
        Me.txtStok.Name = "txtStok"
        Me.txtStok.Size = New System.Drawing.Size(80, 20)
        
        ' txtHarga
        Me.txtHarga.Location = New System.Drawing.Point(520, 140)
        Me.txtHarga.Name = "txtHarga"
        Me.txtHarga.Size = New System.Drawing.Size(120, 20)
        
        ' txtKodeSupplier
        Me.txtKodeSupplier.Location = New System.Drawing.Point(520, 170)
        Me.txtKodeSupplier.Name = "txtKodeSupplier"
        Me.txtKodeSupplier.Size = New System.Drawing.Size(120, 20)

        ' btnRefresh
        Me.btnRefresh.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnRefresh.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold)
        Me.btnRefresh.Location = New System.Drawing.Point(40, 240)
        Me.btnRefresh.Name = "btnRefresh"
        Me.btnRefresh.Size = New System.Drawing.Size(80, 30)
        Me.btnRefresh.Text = "REFRESH"
        Me.btnRefresh.UseVisualStyleBackColor = False
        
        ' btnSave
        Me.btnSave.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold)
        Me.btnSave.Location = New System.Drawing.Point(130, 240)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(80, 30)
        Me.btnSave.Text = "SAVE"
        Me.btnSave.UseVisualStyleBackColor = False
        
        ' btnEdit
        Me.btnEdit.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnEdit.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold)
        Me.btnEdit.Location = New System.Drawing.Point(220, 240)
        Me.btnEdit.Name = "btnEdit"
        Me.btnEdit.Size = New System.Drawing.Size(80, 30)
        Me.btnEdit.Text = "EDIT"
        Me.btnEdit.UseVisualStyleBackColor = False
        
        ' btnDelete
        Me.btnDelete.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold)
        Me.btnDelete.Location = New System.Drawing.Point(310, 240)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(80, 30)
        Me.btnDelete.Text = "DELETE"
        Me.btnDelete.UseVisualStyleBackColor = False
        
        ' btnExit
        Me.btnExit.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold)
        Me.btnExit.Location = New System.Drawing.Point(400, 240)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(80, 30)
        Me.btnExit.Text = "EXIT"
        Me.btnExit.UseVisualStyleBackColor = False

        ' Label11
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.Label11.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label11.Location = New System.Drawing.Point(40, 290)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(74, 18)
        Me.Label11.Text = "Pencarian"

        ' txtCariData
        Me.txtCariData.Location = New System.Drawing.Point(130, 290)
        Me.txtCariData.Name = "txtCariData"
        Me.txtCariData.Size = New System.Drawing.Size(650, 20)
        
        ' btnCariData
        Me.btnCariData.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnCariData.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold)
        Me.btnCariData.Location = New System.Drawing.Point(790, 289)
        Me.btnCariData.Name = "btnCariData"
        Me.btnCariData.Size = New System.Drawing.Size(90, 22)
        Me.btnCariData.Text = "CARI DATA"
        Me.btnCariData.UseVisualStyleBackColor = False

        ' ListView1
        Me.ListView1.FullRowSelect = True
        Me.ListView1.GridLines = True
        Me.ListView1.Location = New System.Drawing.Point(40, 320)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(840, 200)
        Me.ListView1.TabIndex = 32
        Me.ListView1.View = System.Windows.Forms.View.Details

        ' Panel1
        Me.Panel1.BackColor = System.Drawing.Color.DarkSlateGray
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.txtKodeSepatu)
        Me.Panel1.Controls.Add(Me.txtNamaSepatu)
        Me.Panel1.Controls.Add(Me.txtMerk)
        Me.Panel1.Controls.Add(Me.txtUkuran)
        Me.Panel1.Controls.Add(Me.txtWarna)
        Me.Panel1.Controls.Add(Me.cbSneakers)
        Me.Panel1.Controls.Add(Me.cbFormal)
        Me.Panel1.Controls.Add(Me.cbCasual)
        Me.Panel1.Controls.Add(Me.cbSport)
        Me.Panel1.Controls.Add(Me.cbBoots)
        Me.Panel1.Controls.Add(Me.txtStok)
        Me.Panel1.Controls.Add(Me.txtHarga)
        Me.Panel1.Controls.Add(Me.txtKodeSupplier)
        Me.Panel1.Controls.Add(Me.btnRefresh)
        Me.Panel1.Controls.Add(Me.btnSave)
        Me.Panel1.Controls.Add(Me.btnEdit)
        Me.Panel1.Controls.Add(Me.btnDelete)
        Me.Panel1.Controls.Add(Me.btnExit)
        Me.Panel1.Controls.Add(Me.Label11)
        Me.Panel1.Controls.Add(Me.txtCariData)
        Me.Panel1.Controls.Add(Me.btnCariData)
        Me.Panel1.Controls.Add(Me.ListView1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(920, 550)
        Me.Panel1.TabIndex = 0

        ' FormSepatu
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(920, 550)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "FormSepatu"
        Me.Text = "Data Sepatu - SCM Sepatu Fauza"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txtKodeSepatu As System.Windows.Forms.TextBox
    Friend WithEvents txtNamaSepatu As System.Windows.Forms.TextBox
    Friend WithEvents txtMerk As System.Windows.Forms.TextBox
    Friend WithEvents txtUkuran As System.Windows.Forms.TextBox
    Friend WithEvents txtWarna As System.Windows.Forms.TextBox
    Friend WithEvents cbSneakers As System.Windows.Forms.CheckBox
    Friend WithEvents cbFormal As System.Windows.Forms.CheckBox
    Friend WithEvents cbCasual As System.Windows.Forms.CheckBox
    Friend WithEvents cbSport As System.Windows.Forms.CheckBox
    Friend WithEvents cbBoots As System.Windows.Forms.CheckBox
    Friend WithEvents txtStok As System.Windows.Forms.TextBox
    Friend WithEvents txtHarga As System.Windows.Forms.TextBox
    Friend WithEvents txtKodeSupplier As System.Windows.Forms.TextBox
    Friend WithEvents btnRefresh As System.Windows.Forms.Button
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnEdit As System.Windows.Forms.Button
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtCariData As System.Windows.Forms.TextBox
    Friend WithEvents btnCariData As System.Windows.Forms.Button
    Friend WithEvents ListView1 As System.Windows.Forms.ListView
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
End Class
