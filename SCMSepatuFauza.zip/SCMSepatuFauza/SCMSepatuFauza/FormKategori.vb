Imports MySql.Data.MySqlClient

Public Class FormKategori
    Dim a As MsgBoxResult

    Private Sub Posisilist()
        With ListView1.Columns
            .Add("Kode Kategori", 100)
            .Add("Nama Kategori", 200)
            .Add("Keterangan", 400)
        End With
    End Sub

    Private Sub Isilist()
        Dim a As Integer
        Try
            Query = "SELECT * FROM tblkategori ORDER BY kd_kategori"
            daData = New MySqlDataAdapter(Query, Conn)
            dsData = New DataSet
            daData.Fill(dsData)
            ListView1.Items.Clear()

            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                End With
            Next
        Catch ex As Exception
        End Try
    End Sub

    Private Sub Bersih()
        txtKodeKategori.Text = ""
        txtNamaKategori.Text = ""
        txtKeterangan.Text = ""
    End Sub

    Private Sub caridatakategori()
        Dim a As Integer
        Try
            Query = "SELECT * FROM tblkategori WHERE kd_kategori like '%" & Trim(txtCariData.Text) & "%' or nama_kategori like '%" & Trim(txtCariData.Text) & "%' "
            daData = New MySqlDataAdapter(Query, Conn)
            dsData = New DataSet
            daData.Fill(dsData)
            ListView1.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                End With
            Next
        Catch ex As Exception
        End Try
    End Sub

    Private Sub AmbilDataDariListView()
        With ListView1.SelectedItems
            Try
                txtKodeKategori.Text = .Item(0).SubItems(0).Text
                txtNamaKategori.Text = .Item(0).SubItems(1).Text
                txtKeterangan.Text = .Item(0).SubItems(2).Text
            Catch ex As Exception
            End Try
        End With
    End Sub

    Private Sub FormKategori_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Call KoneksiKeDatabase()
            Call Posisilist()
            Call Isilist()
            Bersih()
        Catch ex As Exception
        End Try
    End Sub

    Private Sub btnRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRefresh.Click
        Bersih()
        Isilist()
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Try
            If txtKodeKategori.Text = "" Or txtNamaKategori.Text = "" Or txtKeterangan.Text = "" Then
                MsgBox("Silahkan lengkapi data terlebih dahulu!", MsgBoxStyle.Critical, "Pesan Data Kosong")
                txtKodeKategori.Focus()
            Else
                Query = "INSERT INTO tblkategori VALUES('" & txtKodeKategori.Text & "','" & txtNamaKategori.Text & "','" & txtKeterangan.Text & "')"
                daData = New MySqlDataAdapter(Query, Conn)
                dsData = New DataSet
                daData.Fill(dsData)
                MsgBox("Data berhasil di simpan!", MsgBoxStyle.Information, "SAVE")
                txtKodeKategori.Focus()
                Isilist()
                Bersih()
            End If
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical, "Error")
            txtKodeKategori.Focus()
        End Try
    End Sub

    Private Sub btnEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEdit.Click
        Try
            If txtKodeKategori.Text = "" Or txtNamaKategori.Text = "" Or txtKeterangan.Text = "" Then
                MsgBox("Silahkan Pilih Data Yang Akan Di Edit!", MsgBoxStyle.Critical, "Pesan Data Kosong")
                txtKodeKategori.Focus()
            Else
                Query = "UPDATE tblkategori SET nama_kategori='" & txtNamaKategori.Text & "',keterangan='" & txtKeterangan.Text & "' WHERE kd_kategori='" & txtKodeKategori.Text & "'"
                daData = New MySqlDataAdapter(Query, Conn)
                dsData = New DataSet
                daData.Fill(dsData)
                Isilist()
                Bersih()
                txtKodeKategori.Focus()
                MsgBox("Data Berhasil Di Edit!", MsgBoxStyle.Information, "Edit Data")
            End If
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        Try
            a = MsgBox("Benar data akan Di Delete ...?", MsgBoxStyle.OkCancel + MsgBoxStyle.Question, "Hapus Data")
            Select Case a
                Case vbCancel
                    txtKodeKategori.Focus()
                    Exit Sub
                Case vbOK
                    If txtKodeKategori.Text = "" Then
                        MsgBox("Input Kode Kategori yang akan di hapus", MsgBoxStyle.Critical, "Data Kosong")
                    Else
                        Query = "DELETE FROM tblkategori WHERE kd_kategori='" & txtKodeKategori.Text & "'"
                        daData = New MySqlDataAdapter(Query, Conn)
                        dsData = New DataSet
                        daData.Fill(dsData)
                        Isilist()
                        Bersih()
                        MsgBox("Data berhasil di delete!", MsgBoxStyle.Information, "Hapus Data")
                    End If
            End Select
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical, "Hapus data")
        End Try
    End Sub

    Private Sub ListView1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListView1.SelectedIndexChanged
        AmbilDataDariListView()
    End Sub

    Private Sub txtCariData_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtCariData.TextChanged
        caridatakategori()
    End Sub

    Private Sub btnCariData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCariData.Click
        caridatakategori()
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
