Imports MySql.Data.MySqlClient

Public Class FormTransaksi
    Dim a As MsgBoxResult

    Private Sub Posisilist()
        With ListView1.Columns
            .Add("ID Transaksi", 80)
            .Add("Tgl Transaksi", 100)
            .Add("Kd Sepatu", 80)
            .Add("Nama Sepatu", 150)
            .Add("Merk", 80)
            .Add("Kd Kategori", 80)
            .Add("Nama Kategori", 100)
            .Add("Kd Supplier", 80)
            .Add("Nama Supplier", 150)
            .Add("Jumlah", 60)
            .Add("Harga Satuan", 100)
            .Add("Diskon %", 80)
            .Add("Total Harga", 100)
            .Add("Metode Bayar", 100)
            .Add("Keterangan", 120)
        End With
    End Sub

    Private Sub Isilist()
        Dim a As Integer
        Try
            ' Menggunakan View querytransaksi untuk menampilkan data lengkap
            Query = "SELECT * FROM querytransaksi ORDER BY id_transaksi"
            daData = New MySqlDataAdapter(Query, Conn)
            dsData = New DataSet
            daData.Fill(dsData)
            ListView1.Items.Clear()

            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item("id_transaksi"))
                    .Items(a).SubItems.Add(CDate(dsData.Tables(0).Rows(a).Item("tgl_transaksi")).ToString("yyyy-MM-dd"))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item("kd_sepatu"))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item("nama_sepatu"))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item("merk"))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item("kd_kategori"))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item("nama_kategori"))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item("kd_supplier"))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item("nama_supplier"))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item("jumlah"))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item("harga_satuan"))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item("diskon"))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item("total_harga"))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item("metode_bayar"))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item("keterangan"))
                End With
            Next
        Catch ex As Exception
        End Try
    End Sub

    Private Sub Bersih()
        txtIdTransaksi.Text = ""
        dtpTanggal.Value = Now
        txtKodeSepatu.Text = ""
        txtNamaSepatu.Text = ""
        txtMerk.Text = ""
        txtKodeKategori.Text = ""
        txtNamaKategori.Text = ""
        txtKodeSupplier.Text = ""
        txtNamaSupplier.Text = ""
        txtJumlah.Text = ""
        txtHargaSatuan.Text = ""
        txtDiskon.Text = "0"
        txtTotalHarga.Text = ""
        cbMetodeBayar.Text = ""
        txtKeterangan.Text = ""
    End Sub

    Private Sub HitungTotal()
        Try
            Dim jml As Integer = 0
            Dim harga As Double = 0
            Dim dskn As Double = 0
            Dim total As Double = 0
            
            If txtJumlah.Text <> "" Then jml = CInt(txtJumlah.Text)
            If txtHargaSatuan.Text <> "" Then harga = CDbl(txtHargaSatuan.Text)
            If txtDiskon.Text <> "" Then dskn = CDbl(txtDiskon.Text)
            
            total = (jml * harga)
            Dim nilaiDiskon As Double = total * (dskn / 100)
            total = total - nilaiDiskon
            
            txtTotalHarga.Text = total.ToString()
        Catch ex As Exception
        End Try
    End Sub

    Private Sub FormTransaksi_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Call KoneksiKeDatabase()
            Call Posisilist()
            Call Isilist()
            Bersih()
        Catch ex As Exception
        End Try
    End Sub

    Private Sub btnCariSepatu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCariSepatu.Click
        FormCariSepatu.ShowDialog()
    End Sub

    Private Sub btnCariKategori_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCariKategori.Click
        FormCariKategori.ShowDialog()
    End Sub

    Private Sub btnCariSupplier_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCariSupplier.Click
        FormCariSupplier.ShowDialog()
    End Sub

    Private Sub txtJumlah_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtJumlah.TextChanged
        HitungTotal()
    End Sub

    Private Sub txtDiskon_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtDiskon.TextChanged
        HitungTotal()
    End Sub

    Private Sub txtHargaSatuan_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtHargaSatuan.TextChanged
        HitungTotal()
    End Sub

    Private Sub btnRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRefresh.Click
        Bersih()
        Isilist()
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Try
            If txtKodeSepatu.Text = "" Or txtKodeKategori.Text = "" Or txtKodeSupplier.Text = "" Or txtJumlah.Text = "" Or cbMetodeBayar.Text = "" Then
                MsgBox("Silahkan lengkapi data terlebih dahulu!", MsgBoxStyle.Critical, "Pesan Data Kosong")
            Else
                Dim tgl As String = dtpTanggal.Value.ToString("yyyy-MM-dd")
                Query = "INSERT INTO tbltransaksi (tgl_transaksi, kd_sepatu, kd_kategori, kd_supplier, jumlah, harga_satuan, diskon, total_harga, metode_bayar, keterangan) VALUES('" & tgl & "','" & txtKodeSepatu.Text & "','" & txtKodeKategori.Text & "','" & txtKodeSupplier.Text & "','" & txtJumlah.Text & "','" & txtHargaSatuan.Text & "','" & txtDiskon.Text & "','" & txtTotalHarga.Text & "','" & cbMetodeBayar.Text & "','" & txtKeterangan.Text & "')"
                daData = New MySqlDataAdapter(Query, Conn)
                dsData = New DataSet
                daData.Fill(dsData)
                MsgBox("Transaksi berhasil di simpan!", MsgBoxStyle.Information, "SAVE")
                Isilist()
                Bersih()
            End If
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        Try
            a = MsgBox("Benar transaksi akan Di Delete ...?", MsgBoxStyle.OkCancel + MsgBoxStyle.Question, "Hapus Data")
            Select Case a
                Case vbCancel
                    Exit Sub
                Case vbOK
                    If txtIdTransaksi.Text = "" Then
                        MsgBox("Pilih data transaksi yang akan di hapus", MsgBoxStyle.Critical, "Data Kosong")
                    Else
                        Query = "DELETE FROM tbltransaksi WHERE id_transaksi='" & txtIdTransaksi.Text & "'"
                        daData = New MySqlDataAdapter(Query, Conn)
                        dsData = New DataSet
                        daData.Fill(dsData)
                        Isilist()
                        Bersih()
                        MsgBox("Data berhasil di delete!", MsgBoxStyle.Information, "Hapus Data")
                    End If
            End Select
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical, "Hapus data")
        End Try
    End Sub

    Private Sub ListView1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListView1.SelectedIndexChanged
        With ListView1.SelectedItems
            Try
                txtIdTransaksi.Text = .Item(0).SubItems(0).Text
                dtpTanggal.Value = CDate(.Item(0).SubItems(1).Text)
                txtKodeSepatu.Text = .Item(0).SubItems(2).Text
                txtNamaSepatu.Text = .Item(0).SubItems(3).Text
                txtMerk.Text = .Item(0).SubItems(4).Text
                txtKodeKategori.Text = .Item(0).SubItems(5).Text
                txtNamaKategori.Text = .Item(0).SubItems(6).Text
                txtKodeSupplier.Text = .Item(0).SubItems(7).Text
                txtNamaSupplier.Text = .Item(0).SubItems(8).Text
                txtJumlah.Text = .Item(0).SubItems(9).Text
                txtHargaSatuan.Text = .Item(0).SubItems(10).Text
                txtDiskon.Text = .Item(0).SubItems(11).Text
                txtTotalHarga.Text = .Item(0).SubItems(12).Text
                cbMetodeBayar.Text = .Item(0).SubItems(13).Text
                txtKeterangan.Text = .Item(0).SubItems(14).Text
            Catch ex As Exception
            End Try
        End With
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
