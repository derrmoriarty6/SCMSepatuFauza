Imports MySql.Data.MySqlClient

Module BukaKoneksi
    Public Conn As MySqlConnection
    Public daData As MySqlDataAdapter
    Public dsData As DataSet
    Public Query As String
    Public RD As MySqlDataReader
    Public cmd As MySqlCommand

    Public Sub KoneksiKeDatabase()
        Try
            Dim str As String = "server=localhost;user id=root;password=;database=db_sepatu_fauza"
            Conn = New MySqlConnection(str)

            If Conn.State = ConnectionState.Closed Then
                Conn.Open()
            End If

        Catch ex As Exception
            MsgBox("Koneksi ke server gagal! " & vbCrLf & ex.Message, MsgBoxStyle.Critical, "Error Koneksi")
        End Try
    End Sub
End Module
