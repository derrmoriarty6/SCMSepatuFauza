Imports MySql.Data.MySqlClient

Public Class FormSupplier
    Dim a As MsgBoxResult

    Private Sub Posisilist()
        With ListView1.Columns
            .Add("Kode Supplier", 100)
            .Add("Nama Supplier", 200)
            .Add("Alamat", 300)
            .Add("Telepon", 120)
        End With
    End Sub

    Private Sub Isilist()
        Dim a As Integer
        Try
            Query = "SELECT * FROM tblsupplier ORDER BY kd_supplier"
            daData = New MySqlDataAdapter(Query, Conn)
            dsData = New DataSet
            daData.Fill(dsData)
            ListView1.Items.Clear()

            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                End With
            Next
        Catch ex As Exception
        End Try
    End Sub

    Private Sub Bersih()
        txtKodeSupplier.Text = ""
        txtNamaSupplier.Text = ""
        txtAlamat.Text = ""
        txtTelp.Text = ""
    End Sub

    Private Sub caridatasupplier()
        Dim a As Integer
        Try
            Query = "SELECT * FROM tblsupplier WHERE kd_supplier like '%" & Trim(txtCariData.Text) & "%' or nama_supplier like '%" & Trim(txtCariData.Text) & "%' "
            daData = New MySqlDataAdapter(Query, Conn)
            dsData = New DataSet
            daData.Fill(dsData)
            ListView1.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                End With
            Next
        Catch ex As Exception
        End Try
    End Sub

    Private Sub AmbilDataDariListView()
        With ListView1.SelectedItems
            Try
                txtKodeSupplier.Text = .Item(0).SubItems(0).Text
                txtNamaSupplier.Text = .Item(0).SubItems(1).Text
                txtAlamat.Text = .Item(0).SubItems(2).Text
                txtTelp.Text = .Item(0).SubItems(3).Text
            Catch ex As Exception
            End Try
        End With
    End Sub

    Private Sub FormSupplier_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Call KoneksiKeDatabase()
            Call Posisilist()
            Call Isilist()
            Bersih()
        Catch ex As Exception
        End Try
    End Sub

    Private Sub btnRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRefresh.Click
        Bersih()
        Isilist()
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Try
            If txtKodeSupplier.Text = "" Or txtNamaSupplier.Text = "" Or txtAlamat.Text = "" Or txtTelp.Text = "" Then
                MsgBox("Silahkan lengkapi data terlebih dahulu!", MsgBoxStyle.Critical, "Pesan Data Kosong")
                txtKodeSupplier.Focus()
            Else
                Query = "INSERT INTO tblsupplier VALUES('" & txtKodeSupplier.Text & "','" & txtNamaSupplier.Text & "','" & txtAlamat.Text & "','" & txtTelp.Text & "')"
                daData = New MySqlDataAdapter(Query, Conn)
                dsData = New DataSet
                daData.Fill(dsData)
                MsgBox("Data berhasil di simpan!", MsgBoxStyle.Information, "SAVE")
                txtKodeSupplier.Focus()
                Isilist()
                Bersih()
            End If
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical, "Error")
            txtKodeSupplier.Focus()
        End Try
    End Sub

    Private Sub btnEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEdit.Click
        Try
            If txtKodeSupplier.Text = "" Or txtNamaSupplier.Text = "" Or txtAlamat.Text = "" Or txtTelp.Text = "" Then
                MsgBox("Silahkan Pilih Data Yang Akan Di Edit!", MsgBoxStyle.Critical, "Pesan Data Kosong")
                txtKodeSupplier.Focus()
            Else
                Query = "UPDATE tblsupplier SET nama_supplier='" & txtNamaSupplier.Text & "',alamat='" & txtAlamat.Text & "',telp='" & txtTelp.Text & "' WHERE kd_supplier='" & txtKodeSupplier.Text & "'"
                daData = New MySqlDataAdapter(Query, Conn)
                dsData = New DataSet
                daData.Fill(dsData)
                Isilist()
                Bersih()
                txtKodeSupplier.Focus()
                MsgBox("Data Berhasil Di Edit!", MsgBoxStyle.Information, "Edit Data")
            End If
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        Try
            a = MsgBox("Benar data akan Di Delete ...?", MsgBoxStyle.OkCancel + MsgBoxStyle.Question, "Hapus Data")
            Select Case a
                Case vbCancel
                    txtKodeSupplier.Focus()
                    Exit Sub
                Case vbOK
                    If txtKodeSupplier.Text = "" Then
                        MsgBox("Input Kode Supplier yang akan di hapus", MsgBoxStyle.Critical, "Data Kosong")
                    Else
                        Query = "DELETE FROM tblsupplier WHERE kd_supplier='" & txtKodeSupplier.Text & "'"
                        daData = New MySqlDataAdapter(Query, Conn)
                        dsData = New DataSet
                        daData.Fill(dsData)
                        Isilist()
                        Bersih()
                        MsgBox("Data berhasil di delete!", MsgBoxStyle.Information, "Hapus Data")
                    End If
            End Select
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical, "Hapus data")
        End Try
    End Sub

    Private Sub ListView1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListView1.SelectedIndexChanged
        AmbilDataDariListView()
    End Sub

    Private Sub txtCariData_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtCariData.TextChanged
        caridatasupplier()
    End Sub

    Private Sub btnCariData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCariData.Click
        caridatasupplier()
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
