Imports MySql.Data.MySqlClient

Public Class FormCariSepatu
    Private Sub Posisilist()
        With ListView1.Columns
            .Add("Kode Sepatu", 80)
            .Add("Nama Sepatu", 150)
            .Add("Merk", 80)
            .Add("Ukuran", 60)
            .Add("Warna", 80)
            .Add("Jenis", 80)
            .Add("Stok", 60)
            .Add("Harga", 80)
        End With
    End Sub

    Private Sub Isilist()
        Dim a As Integer
        Try
            Query = "SELECT * FROM tblsepatu ORDER BY kd_sepatu"
            daData = New MySqlDataAdapter(Query, Conn)
            dsData = New DataSet
            daData.Fill(dsData)
            ListView1.Items.Clear()

            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(4))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(5))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(6))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(7))
                End With
            Next
        Catch ex As Exception
        End Try
    End Sub

    Private Sub caridatasepatu()
        Dim a As Integer
        Try
            Query = "SELECT * FROM tblsepatu WHERE kd_sepatu like '%" & Trim(txtCariData.Text) & "%' or nama_sepatu like '%" & Trim(txtCariData.Text) & "%' "
            daData = New MySqlDataAdapter(Query, Conn)
            dsData = New DataSet
            daData.Fill(dsData)
            ListView1.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(4))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(5))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(6))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(7))
                End With
            Next
        Catch ex As Exception
        End Try
    End Sub

    Private Sub FormCariSepatu_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Call KoneksiKeDatabase()
            Call Posisilist()
            Call Isilist()
        Catch ex As Exception
        End Try
    End Sub

    Private Sub txtCariData_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtCariData.TextChanged
        caridatasepatu()
    End Sub

    Private Sub btnCariData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCariData.Click
        caridatasepatu()
    End Sub

    Private Sub ListView1_DoubleClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListView1.DoubleClick
        With ListView1.SelectedItems
            Try
                FormTransaksi.txtKodeSepatu.Text = .Item(0).SubItems(0).Text
                FormTransaksi.txtNamaSepatu.Text = .Item(0).SubItems(1).Text
                FormTransaksi.txtMerk.Text = .Item(0).SubItems(2).Text
                FormTransaksi.txtHargaSatuan.Text = .Item(0).SubItems(7).Text
                Me.Close()
            Catch ex As Exception
            End Try
        End With
    End Sub
End Class
