Imports MySql.Data.MySqlClient

Public Class FormSepatu
    Dim jenis As String
    Dim a As MsgBoxResult

    Private Sub Posisilist()
        With ListView1.Columns
            .Add("Kode Sepatu", 80)
            .Add("Nama Sepatu", 150)
            .Add("Merk", 80)
            .Add("Ukuran", 60)
            .Add("Warna", 80)
            .Add("Jenis", 80)
            .Add("Stok", 60)
            .Add("Harga", 80)
            .Add("Kode Supplier", 80)
        End With
    End Sub

    Private Sub Isilist()
        Dim a As Integer
        Try
            Query = "SELECT * FROM tblsepatu ORDER BY kd_sepatu"
            daData = New MySqlDataAdapter(Query, Conn)
            dsData = New DataSet
            daData.Fill(dsData)
            ListView1.Items.Clear()

            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(4))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(5))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(6))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(7))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(8))
                End With
            Next
        Catch ex As Exception
        End Try
    End Sub

    Private Sub Bersih()
        txtKodeSepatu.Text = ""
        txtNamaSepatu.Text = ""
        txtMerk.Text = ""
        txtUkuran.Text = ""
        txtWarna.Text = ""
        cbSneakers.Checked = False
        cbFormal.Checked = False
        cbCasual.Checked = False
        cbSport.Checked = False
        cbBoots.Checked = False
        txtStok.Text = ""
        txtHarga.Text = ""
        txtKodeSupplier.Text = ""
        jenis = ""
    End Sub

    Private Sub caridatasepatu()
        Dim a As Integer
        Try
            Query = "SELECT * FROM tblsepatu WHERE kd_sepatu like '%" & Trim(txtCariData.Text) & "%' or nama_sepatu like '%" & Trim(txtCariData.Text) & "%' "
            daData = New MySqlDataAdapter(Query, Conn)
            dsData = New DataSet
            daData.Fill(dsData)
            ListView1.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(4))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(5))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(6))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(7))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(8))
                End With
            Next
        Catch ex As Exception
        End Try
    End Sub

    Private Sub AmbilDataDariListView()
        With ListView1.SelectedItems
            Try
                txtKodeSepatu.Text = .Item(0).SubItems(0).Text
                txtNamaSepatu.Text = .Item(0).SubItems(1).Text
                txtMerk.Text = .Item(0).SubItems(2).Text
                txtUkuran.Text = .Item(0).SubItems(3).Text
                txtWarna.Text = .Item(0).SubItems(4).Text
                
                Dim jns As String = .Item(0).SubItems(5).Text
                cbSneakers.Checked = False
                cbFormal.Checked = False
                cbCasual.Checked = False
                cbSport.Checked = False
                cbBoots.Checked = False
                If jns = "Sneakers" Then cbSneakers.Checked = True
                If jns = "Formal" Then cbFormal.Checked = True
                If jns = "Casual" Then cbCasual.Checked = True
                If jns = "Sport" Then cbSport.Checked = True
                If jns = "Boots" Then cbBoots.Checked = True
                jenis = jns

                txtStok.Text = .Item(0).SubItems(6).Text
                txtHarga.Text = .Item(0).SubItems(7).Text
                txtKodeSupplier.Text = .Item(0).SubItems(8).Text
            Catch ex As Exception
            End Try
        End With
    End Sub

    Private Sub FormSepatu_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Call KoneksiKeDatabase()
            Call Posisilist()
            Call Isilist()
            Bersih()
        Catch ex As Exception
        End Try
    End Sub

    Private Sub cbSneakers_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbSneakers.CheckedChanged
        If cbSneakers.Checked = True Then
            cbFormal.Checked = False
            cbCasual.Checked = False
            cbSport.Checked = False
            cbBoots.Checked = False
            jenis = "Sneakers"
        End If
    End Sub

    Private Sub cbFormal_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbFormal.CheckedChanged
        If cbFormal.Checked = True Then
            cbSneakers.Checked = False
            cbCasual.Checked = False
            cbSport.Checked = False
            cbBoots.Checked = False
            jenis = "Formal"
        End If
    End Sub

    Private Sub cbCasual_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbCasual.CheckedChanged
        If cbCasual.Checked = True Then
            cbSneakers.Checked = False
            cbFormal.Checked = False
            cbSport.Checked = False
            cbBoots.Checked = False
            jenis = "Casual"
        End If
    End Sub

    Private Sub cbSport_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbSport.CheckedChanged
        If cbSport.Checked = True Then
            cbSneakers.Checked = False
            cbFormal.Checked = False
            cbCasual.Checked = False
            cbBoots.Checked = False
            jenis = "Sport"
        End If
    End Sub

    Private Sub cbBoots_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbBoots.CheckedChanged
        If cbBoots.Checked = True Then
            cbSneakers.Checked = False
            cbFormal.Checked = False
            cbCasual.Checked = False
            cbSport.Checked = False
            jenis = "Boots"
        End If
    End Sub

    Private Sub btnRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRefresh.Click
        Bersih()
        Isilist()
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Try
            If txtKodeSepatu.Text = "" Or txtNamaSepatu.Text = "" Or jenis = "" Or txtStok.Text = "" Or txtHarga.Text = "" Then
                MsgBox("Silahkan lengkapi data terlebih dahulu!", MsgBoxStyle.Critical, "Pesan Data Kosong")
                txtKodeSepatu.Focus()
            Else
                Query = "INSERT INTO tblsepatu VALUES('" & txtKodeSepatu.Text & "','" & txtNamaSepatu.Text & "','" & txtMerk.Text & "','" & txtUkuran.Text & "','" & txtWarna.Text & "','" & jenis & "','" & txtStok.Text & "','" & txtHarga.Text & "','" & txtKodeSupplier.Text & "')"
                daData = New MySqlDataAdapter(Query, Conn)
                dsData = New DataSet
                daData.Fill(dsData)
                MsgBox("Data berhasil di simpan!", MsgBoxStyle.Information, "SAVE")
                txtKodeSepatu.Focus()
                Isilist()
                Bersih()
            End If
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical, "Error")
            txtKodeSepatu.Focus()
        End Try
    End Sub

    Private Sub btnEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEdit.Click
        Try
            If txtKodeSepatu.Text = "" Or txtNamaSepatu.Text = "" Or jenis = "" Or txtStok.Text = "" Or txtHarga.Text = "" Then
                MsgBox("Silahkan Pilih Data Yang Akan Di Edit!", MsgBoxStyle.Critical, "Pesan Data Kosong")
                txtKodeSepatu.Focus()
            Else
                Query = "UPDATE tblsepatu SET nama_sepatu='" & txtNamaSepatu.Text & "',merk='" & txtMerk.Text & "',ukuran='" & txtUkuran.Text & "',warna='" & txtWarna.Text & "',jenis='" & jenis & "',stok='" & txtStok.Text & "',harga='" & txtHarga.Text & "',kd_supplier='" & txtKodeSupplier.Text & "' WHERE kd_sepatu='" & txtKodeSepatu.Text & "'"
                daData = New MySqlDataAdapter(Query, Conn)
                dsData = New DataSet
                daData.Fill(dsData)
                Isilist()
                Bersih()
                txtKodeSepatu.Focus()
                MsgBox("Data Berhasil Di Edit!", MsgBoxStyle.Information, "Edit Data")
            End If
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        Try
            a = MsgBox("Benar data akan Di Delete ...?", MsgBoxStyle.OkCancel + MsgBoxStyle.Question, "Hapus Data")
            Select Case a
                Case vbCancel
                    txtKodeSepatu.Focus()
                    Exit Sub
                Case vbOK
                    If txtKodeSepatu.Text = "" Then
                        MsgBox("Input Kode Sepatu yang akan di hapus", MsgBoxStyle.Critical, "Data Kosong")
                    Else
                        Query = "DELETE FROM tblsepatu WHERE kd_sepatu='" & txtKodeSepatu.Text & "'"
                        daData = New MySqlDataAdapter(Query, Conn)
                        dsData = New DataSet
                        daData.Fill(dsData)
                        Isilist()
                        Bersih()
                        MsgBox("Data berhasil di delete!", MsgBoxStyle.Information, "Hapus Data")
                    End If
            End Select
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical, "Hapus data")
        End Try
    End Sub

    Private Sub ListView1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListView1.SelectedIndexChanged
        AmbilDataDariListView()
    End Sub

    Private Sub txtCariData_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtCariData.TextChanged
        caridatasepatu()
    End Sub

    Private Sub btnCariData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCariData.Click
        caridatasepatu()
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
